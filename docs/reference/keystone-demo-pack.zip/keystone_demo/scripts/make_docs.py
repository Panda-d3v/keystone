import csv, os, io, random
from email.message import EmailMessage
from email.utils import format_datetime
from datetime import datetime, timezone, timedelta
from reportlab.lib.pagesizes import letter, A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib import colors
from PIL import Image, ImageFilter, ImageDraw, ImageEnhance
random.seed(7)
D="/home/claude/keystone_demo/data"; O="/home/claude/keystone_demo/docs"
parts={r["part_no"]:r for r in csv.DictReader(open(f"{D}/parts.csv"))}

def wrap(c, text, x, y, width, size=10, lead=13, font="Helvetica"):
    c.setFont(font,size); words=text.split(); line=""
    for w in words:
        t=(line+" "+w).strip()
        if c.stringWidth(t,font,size)>width: c.drawString(x,y,line); y-=lead; line=w
        else: line=t
    if line: c.drawString(x,y,line); y-=lead
    return y

def demo_banner(c,W,H):
    c.saveState(); c.setFillColor(colors.HexColor("#B42318")); c.setFont("Helvetica-Bold",8)
    c.drawCentredString(W/2,H-18,"FICTIONAL DEMO DOCUMENT - KEYSTONE HACKATHON DATASET - NOT A REAL TRADE NOTICE OR CERTIFICATE")
    c.restoreState()

# ---------- 1. Trade advisory bulletin PDF (fictional broker newsletter, illustrative scenario) ----------
bul=f"{O}/HTA-2026-118_trade_advisory.pdf"
c=canvas.Canvas(bul,pagesize=letter); W,H=letter; demo_banner(c,W,H)
c.setFillColor(colors.HexColor("#0B3B60")); c.rect(0,H-90,W,62,fill=1,stroke=0)
c.setFillColor(colors.white); c.setFont("Helvetica-Bold",18); c.drawString(54,H-62,"Harborline Trade Advisory")
c.setFont("Helvetica",10); c.drawString(54,H-78,"Client alert HTA-2026-118  |  November 13, 2026  |  Harborline Customs Brokerage LLC (fictional)")
c.setFillColor(colors.black); y=H-122
c.setFont("Helvetica-Bold",14); y=wrap(c,"Illustrative scenario: Section 232 derivative pump and valve parts move to the 50% tier",54,y,W-108,14,18,"Helvetica-Bold")
y-=6
y=wrap(c,"Summary. For this exercise, assume a new proclamation reclassifies certain derivative steel and iron articles from Annex I-B (25% of full customs value) to Annex I-A (50% of full customs value). The change applies to goods entered for consumption, or withdrawn from warehouse, on or after 12:01 a.m. EST on December 1, 2026.",54,y,W-108)
y-=8; c.setFont("Helvetica-Bold",11); c.drawString(54,y,"Affected headings (HTS, 6-digit level)"); y-=16
rows=[("8413.91","Parts of pumps for liquids","25%","50%"),("8481.30","Check (nonreturn) valves","25%","50%"),("8481.80","Other taps, cocks, valves","25%","50%"),("8483.30","Bearing housings; plain shaft bearings","25%","50%")]
c.setFont("Helvetica-Bold",9.5); xs=[54,130,370,450]
for x,h in zip(xs,["HTS","Description","Current rate","New rate"]): c.drawString(x,y,h)
y-=4; c.line(54,y,W-54,y); y-=13; c.setFont("Helvetica",9.5)
for r in rows:
    for x,v in zip(xs,r): c.drawString(x,y,v)
    y-=14
y-=6
y=wrap(c,"Basis. Duty is assessed on the full customs value of the article, regardless of metal content. Only one Section 232 metals duty applies per article; duties do not stack across steel, aluminum and copper.",54,y,W-108)
y-=4
y=wrap(c,"United Kingdom. Qualifying U.K.-origin goods continue to drop one tier (50% to 25%; 25% to 15%) only where the importer can document that the steel or iron was melted and poured in the United Kingdom. Importers should hold mill certificates showing melt location for each heat.",54,y,W-108)
y-=4
y=wrap(c,"Unchanged. Articles of Chapters 72 and 73 already at 50% are unaffected. Section 301, AD/CVD and other duty layers are not addressed in this alert.",54,y,W-108)
y-=8; c.setFont("Helvetica-Bold",11); c.drawString(54,y,"Recommended actions"); y-=15
for t in ["Identify open purchase orders for the headings above with estimated entry on or after December 1, 2026.","Re-run landed cost for any supplier award priced at the 25% rate.","Request melt-and-pour evidence from U.K. suppliers before relying on the reduced U.K. rate."]:
    y=wrap(c,"-  "+t,62,y,W-124)
c.setFont("Helvetica-Oblique",8); c.setFillColor(colors.HexColor("#555555"))
wrap(c,"This alert describes a hypothetical scenario created for a hackathon demo. It is not legal advice, not a customs ruling and not issued by any government agency. Harborline Customs Brokerage LLC is a fictional company.",54,60,W-108,8,10,"Helvetica-Oblique")
c.save()

# ---------- 2. The email (.eml) carrying the bulletin ----------
m=EmailMessage()
m["From"]="Dana Ortiz <alerts@harborline-trade.example>"
m["To"]="sourcing@meridianflow.example"
m["Subject"]="[Client alert] HTA-2026-118: pump and valve parts move to 50% tier Dec 1 (illustrative)"
m["Date"]=format_datetime(datetime(2026,11,13,16,42,tzinfo=timezone(timedelta(hours=-5))))
m.set_content("""Hi MeridianFlow team,

Heads up on today's alert (attached). Under the scenario in HTA-2026-118, derivative
pump parts (8413.91), check valves (8481.30), other valves (8481.80) and bearing
housings (8483.30) move from the 25% tier to the 50% tier of Section 232, assessed on
full customs value, for entries on or after December 1, 2026.

Your open POs with January entries look exposed. If you plan to lean on U.K. sourcing,
make sure you have melt-and-pour evidence in hand before relying on the reduced U.K. rate.

Happy to walk through it Monday.

Dana Ortiz
Harborline Customs Brokerage (fictional, demo data)
""")
m.add_attachment(open(bul,"rb").read(),maintype="application",subtype="pdf",filename=os.path.basename(bul))
open(f"{O}/01_bulletin_email_HTA-2026-118.eml","wb").write(bytes(m))

# ---------- 3. Mill certificate (EN 10204 3.1 style) ----------
def mill_cert(path, supplier, addr, country, cert_no, po, part_no, heats, melt_loc, material, chem, mech, signer, date):
    c=canvas.Canvas(path,pagesize=A4); W,H=A4; demo_banner(c,W,H)
    c.setFont("Helvetica-Bold",15); c.drawString(40,H-56,supplier)
    c.setFont("Helvetica",9); c.drawString(40,H-70,addr)
    c.setFont("Helvetica-Bold",13); c.drawRightString(W-40,H-56,"INSPECTION CERTIFICATE")
    c.setFont("Helvetica",9); c.drawRightString(W-40,H-70,"Type 3.1 per EN 10204:2004")
    c.line(40,H-80,W-40,H-80)
    p=parts[part_no]; y=H-100
    kv=[("Certificate No.",cert_no),("Date of issue",date),("Customer","MeridianFlow Inc., Houston, TX, USA"),("Customer PO",po),
        ("Part number",part_no),("Description",p["description"]),("Material specification",material),("HS code (declared)",p["hts10"][:4]+"."+p["hts10"][4:6]+"."+p["hts10"][6:8]),
        ("Country of origin",country),("Melt location (melted and poured)",melt_loc)]
    for k,v in kv:
        c.setFont("Helvetica-Bold",9); c.drawString(40,y,k); c.setFont("Helvetica",9); c.drawString(210,y,v); y-=15
    y-=6; c.setFont("Helvetica-Bold",10); c.drawString(40,y,"Heat / batch"); y-=4; c.line(40,y,W-40,y); y-=13
    c.setFont("Helvetica-Bold",8.5); hx=[40,120,190]
    c.drawString(40,y,"Heat no."); c.drawString(120,y,"Qty (pcs)"); c.drawString(190,y,"Chemical composition (wt %)"); y-=12
    c.setFont("Helvetica",8.5)
    for h,q in heats:
        c.drawString(40,y,h); c.drawString(120,y,str(q)); c.drawString(190,y,chem); y-=12
    y-=8; c.setFont("Helvetica-Bold",10); c.drawString(40,y,"Mechanical properties"); y-=4; c.line(40,y,W-40,y); y-=13
    c.setFont("Helvetica",8.5)
    for t in mech: c.drawString(40,y,t); y-=12
    y-=8; c.setFont("Helvetica",8.5)
    y=wrap(c,"We hereby certify that the material described above has been manufactured, inspected and tested in accordance with the order requirements and the referenced specification, and that the results comply.",40,y,W-80,8.5,11)
    y-=24; c.setFont("Helvetica-Bold",9); c.drawString(40,y,"Authorized inspection representative"); c.setFont("Helvetica",9); c.drawString(40,y-13,signer)
    c.setStrokeColor(colors.HexColor("#1F3B7A")); c.circle(W-110,y-6,34); c.setFont("Helvetica-Bold",7); c.setFillColor(colors.HexColor("#1F3B7A")); c.drawCentredString(W-110,y-3,"QA RELEASED"); c.drawCentredString(W-110,y-12,"DEMO")
    c.save()

chem_di="C 3.62  Si 2.41  Mn 0.28  P 0.025  S 0.009  Mg 0.042"
mech_di=["Tensile strength 492 MPa (min 448)   Yield strength 331 MPa (min 310)   Elongation 14.5% (min 12)","Hardness 170 HBW   Microstructure: nodularity 92%, ferritic-pearlitic"]
mill_cert(f"{O}/02_mill_cert_Ningbo_MF-8413-005.pdf","Ningbo Haitai Precision Casting Co., Ltd. (fictional)","No. 88 Xingye Road, Beilun District, Ningbo, Zhejiang, China","China","NHPC-26-11427","PO-4504","MF-8413-005",[("H26-3318",120),("H26-3322",80)],"Ningbo, China","ASTM A536 Grade 65-45-12",chem_di,mech_di,"Li Wei, QA Manager","2026-10-28")
clean=f"{O}/_sheffield_clean.pdf"
mill_cert(clean,"Sheffield Forge & Pattern Ltd (fictional)","Unit 4, Attercliffe Works, Sheffield S9 2RX, United Kingdom","United Kingdom","SFP-3.1-07791","Quote Q-2026-0412","MF-8413-005",[("SF-24117",60),("SF-24121",60)],"Sheffield, United Kingdom","ASTM A536 Grade 65-45-12",chem_di,mech_di,"R. Hartley, Quality Lead","2026-11-02")

# ---------- 4. Degrade the Sheffield cert into a bad phone scan ----------
os.system(f"pdftoppm -r 110 -png -singlefile {clean} /tmp/sfp")
im=Image.open("/tmp/sfp.png").convert("L")
W,H=im.size
# coffee stain + smudge over the melt location row
d=ImageDraw.Draw(im)
mx,my=int(W*0.50),int(H*0.281)
for r in range(26,2,-2): d.ellipse([mx-r*6.5,my-r,mx+r*6.5,my+r],fill=118+r*3)
d.line([int(W*0.34),my+2,int(W*0.68),my-3],fill=95,width=7)
im=im.filter(ImageFilter.GaussianBlur(1.6))
im=ImageEnhance.Contrast(im).enhance(0.8); im=ImageEnhance.Brightness(im).enhance(1.08)
im=im.rotate(2.3,expand=True,fillcolor=235)
im=im.resize((int(im.width*0.72),int(im.height*0.72)))
px=im.load()
for _ in range(5000):
    x,y=random.randrange(im.width),random.randrange(im.height); px[x,y]=random.choice([60,90,200])
bg=Image.new("L",(im.width+60,im.height+80),205); bg.paste(im,(26,34))
bg=bg.filter(ImageFilter.GaussianBlur(0.6))
bg.save(f"{O}/03_scan_mill_cert_Sheffield_MF-8413-005.jpg",quality=38)
os.remove(clean); os.remove("/tmp/sfp.png")
print(os.listdir(O))
