import csv, random, json, os
from datetime import date, timedelta
random.seed(42)
OUT = "/home/claude/keystone_demo/data"

# ---------- suppliers (fictional names, real countries/cities) ----------
suppliers = [
 ("S001","Ningbo Haitai Precision Casting Co.","CN","Ningbo"),
 ("S002","Taizhou Jinhong Pump Parts Co.","CN","Taizhou"),
 ("S003","Rajkot Sterling Castings Pvt Ltd","IN","Rajkot"),
 ("S004","Coimbatore Flowtech Components","IN","Coimbatore"),
 ("S005","Monterrey Aceros Industriales SA de CV","MX","Monterrey"),
 ("S006","Queretaro Motores Electricos SA","MX","Queretaro"),
 ("S007","Sheffield Forge & Pattern Ltd","GB","Sheffield"),
 ("S008","Schweinfurt Lagertechnik GmbH","DE","Schweinfurt"),
 ("S009","Taichung Fastener Industrial Co.","TW","Taichung"),
 ("S010","Ohio Valley Foundry Inc.","US","Mansfield"),
 ("S011","Busan Seal Systems Co.","KR","Busan"),
 ("S012","Hai Phong Mechanical JSC","VN","Hai Phong"),
]
# ---------- part families: (desc, hs6, hts10, material, metal_pct, base_price, primary, backup) ----------
fam = [
 ("Pump casing, ductile iron, ANSI B73.1","841391","8413919095","ASTM A536 65-45-12",98,640,"S001","S007"),
 ("Closed impeller, CF8M stainless","841391","8413919095","ASTM A743 CF8M",99,185,"S002","S003"),
 ("Casing cover / backplate, ductile iron","841391","8413919095","ASTM A536",98,210,"S001","S010"),
 ("Bearing frame (power end housing)","841391","8413919095","ASTM A48 Cl.30 gray iron",97,330,"S003","S010"),
 ("Wear ring, bronze","841391","8413919095","C93700 bronze",99,28,"S004","S010"),
 ("Pump shaft, AISI 4140","848310","8483101030","AISI 4140 alloy steel",100,95,"S005","S010"),
 ("Shaft sleeve, 316SS","841391","8413919095","AISI 316",100,42,"S012","S005"),
 ("Cartridge mechanical seal, SiC/SiC","848420","8484200000","SiC faces, 316SS gland",70,310,"S011","S008"),
 ("Deep-groove ball bearing 6309-2Z","848210","8482105044","52100 bearing steel",95,14,"S008","S009"),
 ("Angular contact bearing 7309 BEP pair","848210","8482105048","52100 bearing steel",95,62,"S008","S009"),
 ("Bearing housing, gray iron","848330","8483304000","ASTM A48",97,120,"S003","S010"),
 ("TEFC induction motor, premium efficiency","850152","8501524000","Cast iron frame",65,1450,"S006","S010"),
 ("Flexible jaw coupling","848360","8483608000","Sintered steel / elastomer",80,85,"S009","S005"),
 ("Fabricated steel baseplate","730890","7308909590","ASTM A36",100,220,"S005","S010"),
 ("Flange, weld neck, ASTM A105, Class 150","730791","7307915010","ASTM A105",100,18,"S002","S005"),
 ("Hex cap screw, Grade 5, zinc","731815","7318152065","SAE J429 Gr 5",100,0.42,"S009","S012"),
 ("Hex nut, Grade 5","731816","7318160085","SAE J995 Gr 5",100,0.11,"S009","S012"),
 ("Spiral wound gasket, 316/graphite","848410","8484100000","316SS / flexible graphite",60,3.10,"S012","S004"),
 ("Gate valve, cast steel, Class 150","848180","8481805090","ASTM A216 WCB",95,410,"S003","S005"),
 ("Check valve, swing, ductile iron","848130","8481302090","ASTM A536",95,260,"S004","S005"),
]
sizes = ["1.5x1-6","2x1-8","3x2-6","3x1.5-8","3x2-10","4x3-10","4x3-13"]
parts=[]; sp=[]
i=0
for f in fam:
    desc,hs6,hts,mat,mpct,price,pri,bak = f
    n = 5 if hs6 in ("841391",) else (5 if hs6 in ("731815","731816","730791") else 5)
    for k in range(n):
        i+=1
        pn=f"MF-{hs6[:4]}-{i:03d}"
        sz=sizes[k%len(sizes)]
        scale = 1+0.35*k
        up = round(price*scale,2) if price>1 else round(price*(1+0.25*k),3)
        d = f"{desc}, size {sz}" if hs6 in ("841391","848330","848420") else (f"{desc}, {['1/2-13','5/8-11','3/4-10','7/8-9','1-8'][k]}" if hs6 in ("731815","731816") else (f"{desc}, {['2 in','3 in','4 in','6 in','8 in'][k]}" if hs6 in ("730791","848180","848130") else (f"{desc}, {['5 HP','10 HP','25 HP','40 HP','60 HP'][k]}" if hs6=="850152" else f"{desc}, variant {k+1}")))
        parts.append(dict(part_no=pn,description=d,hs6=hs6,hts10=hts,material=mat,metal_pct_by_weight=mpct,uom="EA"))
        sp.append(dict(supplier_id=pri,part_no=pn,unit_price_usd=up,incoterm="FOB" if pri not in("S010",) else "FCA",lead_time_days=random.choice([42,56,70,84]) if pri!="S010" else 21,is_primary=1))
        bp = round(up*1.15,2) if bak=="S007" else (round(up*random.uniform(1.12,1.38),2) if bak=="S010" else round(up*random.uniform(1.03,1.15),2))
        sp.append(dict(supplier_id=bak,part_no=pn,unit_price_usd=bp,incoterm="FCA" if bak=="S010" else "FOB",lead_time_days=21 if bak=="S010" else random.choice([35,49,63]),is_primary=0))

# products
products=[("P-ANSI-3X2-10","MeridianFlow ANSI end-suction pump 3x2-10, 25 HP",18900,140),
          ("P-VIL-4X3-13","MeridianFlow vertical inline pump 4x3-13, 40 HP",24600,85),
          ("P-SPLIT-6X4-12","MeridianFlow horizontal split-case pump 6x4-12, 60 HP",41200,40)]
bom=[]
for sku,_,_,_ in products:
    for p in parts:
        if random.random()<0.55:
            q = 8 if p["hs6"] in("731815",) else (8 if p["hs6"]=="731816" else (2 if p["hs6"] in("848210","730791","848410") else 1))
            bom.append(dict(sku=sku,part_no=p["part_no"],qty_per=q))

# POs: open/in-transit lines
pos=[]; po=4500
prim={x["part_no"]:x for x in sp if x["is_primary"]==1}
for p in parts:
    if random.random()<0.62:
        po+=1
        s=prim[p["part_no"]]
        q = random.choice([2000,5000,10000]) if p["hs6"] in("731815","731816") else (random.choice([200,400,800]) if p["hs6"] in("730791","848410","848210") else random.choice([40,80,120,200,300]))
        cv=round(q*s["unit_price_usd"],2)
        ship=date(2026,11,20)+timedelta(days=random.randint(0,75))
        st = "in_transit" if ship<date(2026,12,1) else "open"
        pos.append(dict(po_no=f"PO-{po}",line=1,supplier_id=s["supplier_id"],part_no=p["part_no"],qty=q,unit_price_usd=s["unit_price_usd"],customs_value_usd=cv,ship_date=ship.isoformat(),est_entry_date=(ship+timedelta(days=24 if s["supplier_id"] not in("S005","S006","S010") else 4)).isoformat(),status=st))

# baseline tariff layer (Section 232 only, illustrative demo baseline)
base_rate = {"841391":0.25,"848310":0.25,"848420":0.0,"848210":0.0,"848330":0.25,"850152":0.15,"848360":0.0,"730890":0.50,"730791":0.50,"731815":0.50,"731816":0.50,"848410":0.0,"848180":0.25,"848130":0.25}
# scenario: illustrative change effective 2026-12-01: derivative pump & valve parts move I-B (25%) -> I-A (50%)
scope = ["841391","848180","848130","848330"]
EFF = "2026-12-01"
supc={s[0]:s[2] for s in suppliers}
def rate(hs6,country,when_new):
    r = base_rate.get(hs6,0.0)
    if when_new and hs6 in scope: r=0.50
    if country=="US": return 0.0
    if country=="GB" and r>0: r = {0.50:0.25,0.25:0.15}.get(r,r)  # needs melt&pour evidence
    return r
aff_parts=set(); aff_lines=[]; added=0.0
for l in pos:
    p=next(x for x in parts if x["part_no"]==l["part_no"])
    if p["hs6"] in scope and l["est_entry_date"]>=EFF:
        c=supc[l["supplier_id"]]
        d = l["customs_value_usd"]*(rate(p["hs6"],c,True)-rate(p["hs6"],c,False))
        if d>0:
            aff_parts.add(p["part_no"]); aff_lines.append((l["po_no"],p["part_no"],l["supplier_id"],l["customs_value_usd"],round(d,2))); added+=d
# annual exposure (all scope parts, annualized from BOM x units)
units={s:u for s,_,_,u in products}
annual=0
for b in bom:
    p=next(x for x in parts if x["part_no"]==b["part_no"])
    if p["hs6"] in scope:
        s=prim[p["part_no"]]; c=supc[s["supplier_id"]]
        annual+= b["qty_per"]*units[b["sku"]]*s["unit_price_usd"]*(rate(p["hs6"],c,True)-rate(p["hs6"],c,False))
# decisions: March 2026 award of casings to S001
cas=[p for p in parts if p["description"].startswith("Pump casing")]
dec=[]; asm=[]
dec.append(dict(decision_id="D-2026-031",type="supplier_award",subject=";".join(p["part_no"] for p in cas),chosen_option="S001",rationale="Lowest landed cost; Section 232 derivative rate 25% on full value",decided_at="2026-04-20",owner="Sourcing Manager"))
asm.append(dict(assumption_id="A-0311",decision_id="D-2026-031",key="s232_rate:841391:CN",assumed_value=0.25,source_doc_id="DOC-PROC-2026-04-02"))
asm.append(dict(assumption_id="A-0312",decision_id="D-2026-031",key="fx:USD",assumed_value=1.0,source_doc_id="n/a"))
# casing landed cost compare per year
cas_rows=[]
for p in cas:
    ann=sum(b["qty_per"]*units[b["sku"]] for b in bom if b["part_no"]==p["part_no"])
    ps=[x for x in sp if x["part_no"]==p["part_no"]]
    row={"part_no":p["part_no"],"annual_qty":ann}
    for x in ps:
        c=supc[x["supplier_id"]]
        row[x["supplier_id"]+"_old"]=round(ann*x["unit_price_usd"]*(1+rate(p["hs6"],c,False)),0)
        row[x["supplier_id"]+"_new"]=round(ann*x["unit_price_usd"]*(1+rate(p["hs6"],c,True)),0)
        row[x["supplier_id"]+"_new_no_uk_proof"]=round(ann*x["unit_price_usd"]*(1+rate(p["hs6"],"XX",True)),0)
    cas_rows.append(row)

def w(name,rows):
    with open(f"{OUT}/{name}.csv","w",newline="") as fh:
        wr=csv.DictWriter(fh,fieldnames=list(rows[0].keys())); wr.writeheader(); wr.writerows(rows)
w("suppliers",[dict(supplier_id=a,name=b,country_iso2=c,city=d) for a,b,c,d in suppliers])
w("parts",parts); w("supplier_parts",sp); w("products",[dict(sku=a,name=b,list_price_usd=c,annual_units=d) for a,b,c,d in products])
w("bom_lines",bom); w("purchase_orders",pos); w("decisions",dec); w("assumptions",asm)
w("tariff_rates_baseline",[dict(hs6=k,measure="s232_metals",rate=v,basis="full_customs_value",effective_from="2026-04-06") for k,v in base_rate.items()])
print("parts",len(parts),"supplier_parts",len(sp),"bom",len(bom),"po lines",len(pos))
print("affected parts",len(aff_parts),"affected PO lines",len(aff_lines),"added duty",round(added))
print("annualized exposure",round(annual))
print(json.dumps(cas_rows,indent=0))
for a in sorted(aff_lines,key=lambda x:-x[4])[:6]: print(a)
